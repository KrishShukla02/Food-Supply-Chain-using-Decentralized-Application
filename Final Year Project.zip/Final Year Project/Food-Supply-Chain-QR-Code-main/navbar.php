<nav class="navbar navbar-expand-lg navbar-light white" style="position: fixed; width: 100%;z-index: 20;">
  <a class="navbar-brand" style="font-weight: 500; color: #68b803;" href="checkproduct.php">
    <span style="color: #590995;">F</span>ood
    <span style="color: #cf41e0;">S</span>upply
    <span style="color: #e0807a;">C</span>hain
  </a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav" aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon" style="color: #4287f5;"></span>
  </button>

  <div class="collapse navbar-collapse" id="basicExampleNav">
    <ul class="navbar-nav mr-auto">

      <?php
      if (isset($_SESSION['role'])) {
      ?>
        <li class="nav-item">
          <a class="nav-link" href="checkproduct.php">Check Products</a>
        </li>
        <?php
        if ($_SESSION['role'] == 0) {
        ?>
          <li class="nav-item">
            <a class="nav-link" href="addproduct.php">Add Products</a>
          </li>
        <?php
        }
        if ($_SESSION['role'] == 1 || $_SESSION['role'] == 0) {
        ?>
          <li class="nav-item">
            <a class="nav-link" href="scanshipment.php">Scan Shipment</a>
          </li>
      <?php
        }
      }
      ?>
      <li class="nav-item">
        <a class="nav-link" id="aboutbtn"> About </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="fetch_qr.php"> QR Codes </a>
      </li>

    </ul>

    <div class="form-inline my-2 my-lg-0">
      <div class="mr-sm-3" style="font-weight: 500;"><?php echo $_SESSION['username']; ?></div>
    </div>
    <a id="accountAddress" style="font-weight: 400; color:red;"></a>

    <form class="d-flex">
      <div class="md-form my-0">
        <a class="nav-link" href="logout.php"> Logout </a>
      </div>
    </form>

  </div>
</nav>