var contractAbi = [
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "index",
        "type": "uint256"
      }
    ],
    "name": "Added",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "_productId",
        "type": "uint256"
      },
      {
        "internalType": "string",
        "name": "info",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "lname",
        "type": "string"
      }
    ],
    "name": "addState",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "string",
        "name": "_text",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "_mdate",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "_edate",
        "type": "string"
      }
    ],
    "name": "newItem",
    "outputs": [
      {
        "internalType": "bool",
        "name": "",
        "type": "bool"
      }
    ],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "string",
        "name": "_a",
        "type": "string"
      },
      {
        "internalType": "string",
        "name": "_b",
        "type": "string"
      }
    ],
    "name": "concat",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "pure",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "_productId",
        "type": "uint256"
      }
    ],
    "name": "searchProduct",
    "outputs": [
      {
        "internalType": "string",
        "name": "",
        "type": "string"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
];

var contractAddress = "0x2EB7B28e17Cf6cB4b4a7bB490BEb4fB6F5bb13D4";
